<?php
// ===== CONFIGURAÇÃO — edite antes de subir para o servidor =====

// Banco de dados MySQL / MariaDB
define('DB_HOST',    'localhost');
define('DB_NOME',    'alerta_ativo');
define('DB_USUARIO', 'usuario_do_banco');
define('DB_SENHA',   'senha_do_banco');

// Acesso do desenvolvedor (fica só no servidor, nunca vai para o navegador)
define('DEV_LOGIN', 'dev');
define('DEV_SENHA', 'TROQUE-ESTA-SENHA');

// Segredo usado para gerar o link do Painel TV de cada empresa.
// Use um texto longo e aleatório. Se trocar, os links antigos deixam de funcionar.
define('PAINEL_SEGREDO', 'TROQUE-POR-UM-TEXTO-LONGO-E-ALEATORIO');

// Tamanho máximo de cada gravação (bytes)
define('MAX_BODY', 5 * 1024 * 1024);
